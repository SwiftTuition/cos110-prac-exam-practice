#include <iostream>

#include "Item.h"

using namespace std;

Item special() {
    return Item('M', "Chef's special", 150.5);
}

int main() {
    Item a('S', "Soup", 50);
    a = special();
    cout << "from a function: " << a << endl;

    Item* list[2];
    list[0] = new Item('S', "Garlic bread", 45.5);
    list[1] = new Item('D', "Ice cream", 35);
    *list[0] = *list[1];
    cout << "through pointers: " << *list[0] << " and " << *list[1] << endl;
    delete list[0];
    delete list[1];

    Item b('D', "", 0);
    a = b;
    cout << "an empty name: [" << a.getName() << "] price " << a.getPrice() << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
from a function: Chef's special (M) R150.5
through pointers: Ice cream (D) R35 and Ice cream (D) R35
an empty name: [] price 0
*/
