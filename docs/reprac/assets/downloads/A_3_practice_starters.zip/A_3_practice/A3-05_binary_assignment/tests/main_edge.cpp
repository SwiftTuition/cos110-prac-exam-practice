#include <iostream>

#include "Binary.h"

using namespace std;

int main() {
    Binary a("1010");
    Binary empty("");
    a = empty;
    cout << "after a = empty: [" << a << "] size " << a.getSize() << endl;

    Binary b("111");
    a = b;
    a[1] = false;
    cout << "a: " << a << ", b: " << b << endl;

    Binary* p = new Binary("0");
    *p = a;
    cout << "*p: " << *p << endl;
    delete p;
    cout << "a after deleting p: " << a << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
after a = empty: [] size 0
a: 101, b: 111
*p: 101
a after deleting p: 101
*/
