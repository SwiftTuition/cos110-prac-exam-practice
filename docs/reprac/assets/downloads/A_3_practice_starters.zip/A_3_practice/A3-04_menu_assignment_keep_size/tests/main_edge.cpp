#include <iostream>

#include "Item.h"
#include "Menu.h"

using namespace std;

int main() {
    Menu a(3);
    a + new Item('S', "Soup", 50) + new Item('M', "Beef burger", 120) + new Item('D', "Ice cream", 35);
    Menu empty(5);
    a = empty;
    cout << "a after a = empty:" << endl << a;

    a + new Item('M', "Veg curry", 95.5);
    cout << "a after adding Veg curry:" << endl << a;

    Menu zero(0);
    zero = a;
    cout << "a menu of size 0 stays empty:" << endl << zero;
    a = zero;
    cout << "a after a = zero:" << endl << a;
    return 0;
}
/*
ExpectedOutput:
*/
/*
a after a = empty:
Menu (max 3):
  [0] empty
  [1] empty
  [2] empty
a after adding Veg curry:
Menu (max 3):
  [0] Veg curry (M) R95.5
  [1] empty
  [2] empty
a menu of size 0 stays empty:
Menu (max 0):
a after a = zero:
Menu (max 3):
  [0] empty
  [1] empty
  [2] empty
*/
