#include <iostream>

#include "Exception.h"
#include "Item.h"
#include "Menu.h"

using namespace std;

void show(Menu m) {
    cout << "inside show (a copy made by pass-by-value):" << endl << m;
    m + new Item('D', "Ice cream", 35);
}

int main() {
    Menu a(2);
    a + new Item('M', "Veg curry", 95.5);
    show(a);
    cout << "a after show:" << endl << a;

    Menu* p = new Menu(a);
    cout << "average main price in the copy: " << p->averagePrice("Main") << endl;
    delete p;
    cout << "a after deleting the copy:" << endl << a;

    Menu zero(0);
    Menu z(zero);
    cout << z;
    return 0;
}
/*
ExpectedOutput:
*/
/*
inside show (a copy made by pass-by-value):
Menu (max 2):
  [0] Veg curry (M) R95.5
  [1] empty
a after show:
Menu (max 2):
  [0] Veg curry (M) R95.5
  [1] empty
average main price in the copy: 95.5
a after deleting the copy:
Menu (max 2):
  [0] Veg curry (M) R95.5
  [1] empty
Menu (max 0):
*/
