#include <iostream>

#include "Exception.h"
#include "Item.h"
#include "Menu.h"

using namespace std;

int main() {
    cout << "--- 1. an empty menu into a full one ---" << endl;
    Menu full(2);
    full + new Item('M', "Beef burger", 120) + new Item('M', "Veg curry", 95.5);
    Menu empty(3);
    full = empty;
    cout << full;

    cout << "--- 2. the copy works with the other functions ---" << endl;
    Menu b(3);
    b + new Item('S', "Soup", 50) + new Item('M', "Beef burger", 120);
    full = b;
    cout << "first main in the copy: " << full.findFirst("Main") << endl;
    try {
        full.findFirst("Dessert");
    } catch (DessertNotFound& e) {
        cout << "the copy has no dessert: ";
        e.printException();
    }
    full + new Item('D', "Ice cream", 35);
    cout << "the copy after adding Ice cream:" << endl << full;
    cout << "b has not changed:" << endl << b;

    cout << "--- 3. through pointers ---" << endl;
    Menu* p = new Menu(1);
    *p = b;
    delete p;
    cout << "deleting the copy did not touch b:" << endl << b;

    cout << "--- 4. a menu of size 0 ---" << endl;
    Menu zero(0);
    b = zero;
    cout << b;
    b = full;
    cout << b;
    return 0;
}
/*
ExpectedOutput:
*/
/*
--- 1. an empty menu into a full one ---
Menu (max 3):
  [0] empty
  [1] empty
  [2] empty
--- 2. the copy works with the other functions ---
first main in the copy: Beef burger (M) R120
the copy has no dessert: Exception: Item not found
the copy after adding Ice cream:
Menu (max 3):
  [0] Soup (S) R50
  [1] Beef burger (M) R120
  [2] Ice cream (D) R35
b has not changed:
Menu (max 3):
  [0] Soup (S) R50
  [1] Beef burger (M) R120
  [2] empty
--- 3. through pointers ---
deleting the copy did not touch b:
Menu (max 3):
  [0] Soup (S) R50
  [1] Beef burger (M) R120
  [2] empty
--- 4. a menu of size 0 ---
Menu (max 0):
Menu (max 3):
  [0] Soup (S) R50
  [1] Beef burger (M) R120
  [2] Ice cream (D) R35
*/
