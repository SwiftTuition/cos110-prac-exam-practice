# Read this first

Each folder here is one practice question for the COS 110 re-practical.

## Assumed rules

The re-practical paper does not describe the build, the upload or the marking.
These practice questions follow the rules of the HRMS practical exam (31 October 2026):

- a makefile builds your code with `g++ -g -std=c++98 -Wall -Werror`, so every warning stops the build;
- valgrind checks memory;
- you upload only your answer file, for example `A_1.cpp`;
- code that does not build, or a program that stops abnormally, scores 0.

The last part of each `QUESTION.md` uses these rules. They are Assumed, not exam facts.
Where the class diagrams leave a rule open, each question gives the rule it uses.
These rules can differ from one question to the next.
In the exam, the complete UML, the given header files and the question text decide.

## On Windows without make (Assumed)

Open PowerShell in the question's starter folder and run:

    g++ -std=c++98 -Wall -Werror *.cpp -o main
    .\main.exe

This assumes g++ is installed and on the PATH. There is no valgrind on Windows, so check each `new` and `delete` by reading the code.
If the exam gives its own build command, use that command.
