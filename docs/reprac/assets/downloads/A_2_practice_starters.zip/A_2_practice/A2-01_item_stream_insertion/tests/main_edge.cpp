
#include <iostream>
#include <sstream>

#include "Item.h"
#include "Menu.h"

using namespace std;

int main() {
    cout << "-- into a string stream --" << endl;
    ostringstream text;
    text << Item('D', "Ice cream", 35) << ";" << Item('S', "Soup", 50);
    cout << "[" << text.str() << "]" << endl;

    cout << "-- a long name and a price of 0 --" << endl;
    cout << Item('S', "Bread of the day", 0) << endl;

    cout << "-- a copy prints the same --" << endl;
    Item original('M', "Lamb chops", 185.5);
    Item copy(original);
    cout << original << endl << copy << endl;

    cout << "-- a const item --" << endl;
    const Item fixed('D', "Cheesecake", 65.75);
    cout << fixed << "." << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
-- into a string stream --
[Ice cream (D) R35;Soup (S) R50]
-- a long name and a price of 0 --
Bread of the day (S) R0
-- a copy prints the same --
Lamb chops (M) R185.5
Lamb chops (M) R185.5
-- a const item --
Cheesecake (D) R65.75.
*/
