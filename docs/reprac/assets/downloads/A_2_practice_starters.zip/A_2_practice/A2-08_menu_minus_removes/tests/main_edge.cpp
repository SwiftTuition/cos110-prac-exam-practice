
#include <iostream>

#include "Item.h"
#include "Menu.h"

using namespace std;

int main() {
    cout << "-- a full menu: remove the first item --" << endl;
    Menu full(3);
    full + new Item('S', "Soup", 50) + new Item('M', "Lamb chops", 185.5) + new Item('D', "Ice cream", 35);
    full - "Soup";
    cout << full;

    cout << "-- a full menu: remove the last item --" << endl;
    full + new Item('D', "Sorbet", 30);
    full - "Sorbet";
    cout << full;

    cout << "-- two items with the same name: only the first goes --" << endl;
    Menu twins(3);
    twins + new Item('S', "Soup", 50) + new Item('M', "Soup", 80);
    twins - "Soup";
    cout << twins;

    cout << "-- a chain, and a menu of size 0 --" << endl;
    twins - "Soup" - "Soup";
    cout << twins;
    Menu none(0);
    none - "Soup";
    cout << none;
    return 0;
}
/*
ExpectedOutput:
*/
/*
-- a full menu: remove the first item --
Menu (max 3):
  [0] Lamb chops (M) R185.5
  [1] Ice cream (D) R35
  [2] empty
-- a full menu: remove the last item --
Menu (max 3):
  [0] Lamb chops (M) R185.5
  [1] Ice cream (D) R35
  [2] empty
-- two items with the same name: only the first goes --
Menu (max 3):
  [0] Soup (M) R80
  [1] empty
  [2] empty
-- a chain, and a menu of size 0 --
Menu (max 3):
  [0] empty
  [1] empty
  [2] empty
Menu (max 0):
*/
