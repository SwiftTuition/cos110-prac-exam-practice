
#include <iostream>

#include "Item.h"

using namespace std;

void compare(const Item& a, const Item& b) {
    cout << a << " vs " << b << ": ";
    cout << "== " << (a == b ? "true" : "false");
    cout << ", < " << (a < b ? "true" : "false") << endl;
}

int main() {
    cout << "-- same name and price, different type --" << endl;
    compare(Item('S', "Chocolate", 30), Item('D', "Chocolate", 30));
    cout << "-- same type and price, different name --" << endl;
    compare(Item('D', "Ice cream", 35), Item('D', "Sorbet", 35));
    cout << "-- a price of 0 --" << endl;
    Item freeBread('S', "Free bread", 0);
    Item bread('S', "Garlic bread", 45.5);
    compare(freeBread, bread);
    compare(bread, freeBread);
    cout << "-- an item and itself --" << endl;
    compare(bread, bread);
    cout << "-- two temporaries --" << endl;
    compare(Item('S', "Soup", 50), Item('S', "Soup", 50));
    return 0;
}
/*
ExpectedOutput:
*/
/*
-- same name and price, different type --
Chocolate (S) R30 vs Chocolate (D) R30: == false, < false
-- same type and price, different name --
Ice cream (D) R35 vs Sorbet (D) R35: == false, < false
-- a price of 0 --
Free bread (S) R0 vs Garlic bread (S) R45.5: == false, < true
Garlic bread (S) R45.5 vs Free bread (S) R0: == false, < false
-- an item and itself --
Garlic bread (S) R45.5 vs Garlic bread (S) R45.5: == true, < false
-- two temporaries --
Soup (S) R50 vs Soup (S) R50: == true, < false
*/
