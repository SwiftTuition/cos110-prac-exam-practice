
#include <iostream>

#include "Item.h"
#include "Menu.h"

using namespace std;

int main() {
    cout << "-- a menu of size 0 --" << endl;
    Menu none(0);
    none + new Item('S', "Soup", 50);
    cout << none;

    cout << "-- a menu of size 1, three items in one chain --" << endl;
    Menu one(1);
    one + new Item('D', "Ice cream", 35) + new Item('D', "Sorbet", 30) + new Item('D', "Cheesecake", 65.5);
    cout << one;

    cout << "-- the returned reference is the same menu --" << endl;
    Menu two(2);
    Menu& same = two + new Item('M', "Lamb chops", 185.5);
    same + new Item('M', "Fish and chips", 110);
    cout << two;
    return 0;
}
/*
ExpectedOutput:
*/
/*
-- a menu of size 0 --
Menu (max 0):
-- a menu of size 1, three items in one chain --
Menu (max 1):
  [0] Ice cream (D) R35
-- the returned reference is the same menu --
Menu (max 2):
  [0] Lamb chops (M) R185.5
  [1] Fish and chips (M) R110
*/
