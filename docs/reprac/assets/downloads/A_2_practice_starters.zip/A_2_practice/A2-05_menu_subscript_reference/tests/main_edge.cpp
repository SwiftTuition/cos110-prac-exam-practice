
#include <iostream>

#include "Item.h"
#include "Menu.h"

using namespace std;

int main() {
    cout << "-- swap two slots through the references --" << endl;
    Menu menu(3);
    menu + new Item('S', "Garlic bread", 45.5) + new Item('M', "Beef burger", 120);
    Item* temp = menu[0];
    menu[0] = menu[1];
    menu[1] = temp;
    cout << menu;

    cout << "-- fill the empty slot, then operator+ finds the menu full --" << endl;
    menu[2] = new Item('D', "Ice cream", 35);
    menu + new Item('S', "Extra", 1);
    cout << menu;

    cout << "-- read every slot --" << endl;
    for (int i = 0; i < 3; i++) {
        cout << i << ": " << menu[i]->getName() << endl;
    }

    cout << "-- a menu of size 1 --" << endl;
    Menu one(1);
    one[0] = new Item('M', "Lamb chops", 185.5);
    cout << *one[0] << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
-- swap two slots through the references --
Menu (max 3):
  [0] Beef burger (M) R120
  [1] Garlic bread (S) R45.5
  [2] empty
-- fill the empty slot, then operator+ finds the menu full --
Menu (max 3):
  [0] Beef burger (M) R120
  [1] Garlic bread (S) R45.5
  [2] Ice cream (D) R35
-- read every slot --
0: Beef burger
1: Garlic bread
2: Ice cream
-- a menu of size 1 --
Lamb chops (M) R185.5
*/
