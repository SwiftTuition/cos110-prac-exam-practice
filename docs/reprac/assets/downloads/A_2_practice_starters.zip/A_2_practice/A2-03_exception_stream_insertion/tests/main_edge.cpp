
#include <iostream>
#include <sstream>

#include "Exception.h"

using namespace std;

int main() {
    cout << "-- into a string stream --" << endl;
    ostringstream text;
    text << NothingAboveMinimumValue() << " / " << StarterNotFound();
    cout << "[" << text.str() << "]" << endl;

    cout << "-- through a base pointer --" << endl;
    Exception* p = new NothingMatchingFilter("Main");
    cout << *p << endl;
    delete p;

    cout << "-- the same text as printException, without the newline --" << endl;
    InvalidType bad("soup");
    cout << bad << "|" << endl;
    bad.printException();
    return 0;
}
/*
ExpectedOutput:
*/
/*
-- into a string stream --
[Exception: Nothing matching filter: above minimum value / Exception: Item not found]
-- through a base pointer --
Exception: Nothing matching filter: Main
-- the same text as printException, without the newline --
Exception: Invalid type: soup|
Exception: Invalid type: soup
*/
