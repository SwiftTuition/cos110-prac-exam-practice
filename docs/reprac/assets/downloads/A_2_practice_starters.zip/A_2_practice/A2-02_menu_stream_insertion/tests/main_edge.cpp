
#include <iostream>
#include <sstream>

#include "Item.h"
#include "Menu.h"

using namespace std;

int main() {
    cout << "-- a menu of size 0 --" << endl;
    Menu none(0);
    cout << none;

    cout << "-- a menu of size 1 that is full --" << endl;
    Menu one(1);
    one + new Item('D', "Ice cream", 35) + new Item('M', "Extra", 1);
    cout << one;

    cout << "-- into a string stream --" << endl;
    ostringstream text;
    text << one;
    cout << "[" << text.str() << "]" << endl;

    cout << "-- two menus in one chain --" << endl;
    Menu two(2);
    two + new Item('S', "Soup", 50);
    cout << none << two;
    return 0;
}
/*
ExpectedOutput:
*/
/*
-- a menu of size 0 --
Menu (max 0):
-- a menu of size 1 that is full --
Menu (max 1):
  [0] Ice cream (D) R35
-- into a string stream --
[Menu (max 1):
  [0] Ice cream (D) R35
]
-- two menus in one chain --
Menu (max 0):
Menu (max 2):
  [0] Soup (S) R50
  [1] empty
*/
