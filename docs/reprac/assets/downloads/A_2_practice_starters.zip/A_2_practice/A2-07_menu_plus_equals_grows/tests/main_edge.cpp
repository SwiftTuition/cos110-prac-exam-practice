
#include <iostream>

#include "Item.h"
#include "Menu.h"

using namespace std;

int main() {
    cout << "-- a menu of size 0 grows --" << endl;
    Menu none(0);
    none += new Item('S', "Soup", 50);
    cout << none;

    cout << "-- a free slot is used before the array grows --" << endl;
    Menu three(3);
    three += new Item('D', "Ice cream", 35);
    cout << three;

    cout << "-- after growing, operator+ finds the menu full --" << endl;
    Menu one(1);
    one += new Item('M', "Lamb chops", 185.5);
    one += new Item('M', "Fish and chips", 110);
    one + new Item('D', "Extra", 1);
    cout << one;
    return 0;
}
/*
ExpectedOutput:
*/
/*
-- a menu of size 0 grows --
Menu (max 1):
  [0] Soup (S) R50
-- a free slot is used before the array grows --
Menu (max 3):
  [0] Ice cream (D) R35
  [1] empty
  [2] empty
-- after growing, operator+ finds the menu full --
Menu (max 2):
  [0] Lamb chops (M) R185.5
  [1] Fish and chips (M) R110
*/
