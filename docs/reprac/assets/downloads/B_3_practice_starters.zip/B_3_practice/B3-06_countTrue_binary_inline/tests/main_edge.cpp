#include <iostream>

#include "Binary.h"
#include "BinaryStrings.h"
#include "Node.h"
#include "Templates.h"

using namespace std;

int main() {
    // 1. NULL pointers of both types.
    Node<Binary>* noBinary = NULL;
    Node<bool>* noBool = NULL;
    cout << "1. " << countTrue(noBinary) << " " << countTrue(noBool) << endl;

    // 2. The general template for bool.
    Node<bool> b1(true);
    Node<bool> b2(false);
    Node<bool> b3(true);
    b1.next() = &b2;
    b2.next() = &b3;
    cout << "2. " << countTrue(&b1) << endl;

    // 3. Empty strings and zeros have no true bits.
    BinaryStrings list;
    list.prepend(Binary("0000"));
    list.prepend(Binary(""));
    list.prepend(Binary(""));
    cout << "3. [" << list << "]: " << countTrue(list.getHead()) << endl;

    // 4. Characters other than '1' are false bits.
    list.prepend(Binary("1x1x"));
    cout << "4. [" << list << "]: " << countTrue(list.getHead()) << endl;

    // 5. A long string, and the type written out.
    list.prepend(Binary("11111111111111111111"));
    cout << "5. " << countTrue<Binary>(list.getHead()) << endl;

    // 6. A single Node<Binary> that is not in a list.
    Node<Binary> single(Binary("10101"));
    cout << "6. " << countTrue(&single) << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. 0 0
2. 2
3. [ ->  -> 0000]: 0
4. [1010 ->  ->  -> 0000]: 2
5. 22
6. 3
*/
