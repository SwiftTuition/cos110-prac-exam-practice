#include <iostream>
#include <string>

#include "Binary.h"
#include "Templates.h"

using namespace std;

int main() {
    // 1. Two empty strings, and an empty string against "0": equal values return a.
    Binary e1 = largest(Binary(""), Binary(""));
    cout << "1. [" << e1 << "] size " << e1.getSize() << endl;
    Binary e2 = largest(Binary(""), Binary("0"));
    cout << "   [" << e2 << "] size " << e2.getSize() << endl;

    // 2. More 1 bits does not mean larger.
    Binary m = largest(Binary("0111111"), Binary("1000000"));
    cout << "2. " << m << endl;

    // 3. A longer string with a smaller value.
    Binary l = largest(Binary("00000001"), Binary("10"));
    cout << "3. " << l << endl;

    // 4. 31 bits.
    Binary big = largest(Binary("1111111111111111111111111111110"), Binary("1111111111111111111111111111111"));
    cout << "4. " << big << endl;

    // 5. The arguments do not change, and the result is a separate copy.
    Binary p("0101");
    Binary q("0100");
    Binary r = largest(p, q);
    r[3] = false;
    cout << "5. p " << p << ", q " << q << ", changed result " << r << endl;

    // 6. The type written out, and the general template for char and bool.
    Binary t = largest<Binary>(Binary("1"), Binary("10"));
    cout << "6. " << t << ", " << largest('a', 'z') << ", " << largest(false, true) << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. [] size 0
   [] size 0
2. 1000000
3. 10
4. 1111111111111111111111111111111
5. p 0101, q 0100, changed result 0100
6. 10, z, 1
*/
