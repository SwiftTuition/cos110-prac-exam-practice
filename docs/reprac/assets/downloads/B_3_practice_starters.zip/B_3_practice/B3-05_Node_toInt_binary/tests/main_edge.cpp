#include <iostream>

#include "Binary.h"
#include "BinaryStrings.h"
#include "Node.h"

using namespace std;

int main() {
    // 1. The general version for char and a negative double.
    Node<char> c('A');
    Node<double> neg(-2.7);
    cout << "1. " << c.toInt() << " " << neg.toInt() << endl;

    // 2. An empty string and a string of zeros.
    Node<Binary> empty(Binary(""));
    Node<Binary> zeros(Binary("0000"));
    cout << "2. " << empty.toInt() << " " << zeros.toInt() << endl;

    // 3. 31 ones.
    Node<Binary> big(Binary("1111111111111111111111111111111"));
    cout << "3. " << big.toInt() << endl;

    // 4. toInt() reads the current data: change a bit, call it again.
    Node<Binary> b(Binary("0001"));
    cout << "4. " << b.getData() << " -> " << b.toInt();
    b.getData()[0] = true;
    cout << ", " << b.getData() << " -> " << b.toInt() << endl;

    // 5. A node in a list, through a pointer.
    BinaryStrings list;
    list.prepend(Binary("1x1"));
    list.prepend(Binary("110"));
    cout << "5. " << list.getHead()->toInt() << " " << list.getHead()->next()->toInt() << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. 65 -2
2. 0 0
3. 2147483647
4. 0001 -> 1, 1001 -> 9
5. 6 5
*/
