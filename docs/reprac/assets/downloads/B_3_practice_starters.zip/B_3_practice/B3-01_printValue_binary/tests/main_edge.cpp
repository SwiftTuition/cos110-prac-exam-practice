#include <iostream>
#include <string>

#include "Binary.h"
#include "Templates.h"

using namespace std;

int main() {
    // 1. An empty string.
    cout << "1. ";
    printValue(Binary(""));

    // 2. One bit, and all zeros.
    cout << "2. ";
    printValue(Binary("1"));
    cout << "   ";
    printValue(Binary("0000"));

    // 3. A character that is not '1' is a 0 bit.
    cout << "3. ";
    printValue(Binary("1x1"));

    // 4. 31 ones.
    cout << "4. ";
    printValue(Binary("1111111111111111111111111111111"));

    // 5. The type written out, and a const Binary.
    const Binary c("1010");
    cout << "5. ";
    printValue<Binary>(c);
    cout << "   ";
    printValue<int>(-7);

    // 6. The general template still works for a bool.
    cout << "6. ";
    printValue(true);
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. Binary:  (0)
2. Binary: 1 (1)
   Binary: 0000 (0)
3. Binary: 101 (5)
4. Binary: 1111111111111111111111111111111 (2147483647)
5. Binary: 1010 (10)
   Value: -7
6. Value: 1
*/
