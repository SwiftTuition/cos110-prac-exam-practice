#include <iostream>
#include <string>

#include "Binary.h"
#include "Templates.h"

using namespace std;

int main() {
    // 1. The general template: the result has the type of the first argument.
    cout << "1. " << addition(1, 2) << " " << addition('A', 1) << " " << addition(10, 0.9) << endl;

    // 2. Empty strings also throw.
    try {
        addition(Binary(""), Binary(""));
        cout << "2. No exception" << endl;
    } catch (const char* msg) {
        cout << "2. Caught: " << msg << endl;
    }

    // 3. The types written out.
    try {
        Binary r = addition<Binary, Binary>(Binary("1"), Binary("1"));
        cout << "3. " << r << endl;
    } catch (const char* msg) {
        cout << "3. Caught: " << msg << endl;
    }

    // 4. Five calls in a loop: every call throws, and nothing leaks.
    int caught = 0;
    for (int i = 0; i < 5; i++) {
        try {
            addition(Binary("1111"), Binary("0001"));
        } catch (const char* msg) {
            caught++;
        }
    }
    cout << "4. Caught " << caught << " times" << endl;

    // 5. The program continues after the exception.
    cout << "5. Program continues" << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. 3 B 10
2. Caught: Cannot add two binary strings
3. Caught: Cannot add two binary strings
4. Caught 5 times
5. Program continues
*/
