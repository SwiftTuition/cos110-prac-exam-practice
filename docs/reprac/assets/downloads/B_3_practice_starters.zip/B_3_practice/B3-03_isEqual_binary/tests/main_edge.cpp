#include <iostream>
#include <string>

#include "Binary.h"
#include "Templates.h"

using namespace std;

void show(const char* label, const Binary& a, const Binary& b) {
    cout << label << " [" << a << "] and [" << b << "]: " << (isEqual(a, b) ? "equal" : "not equal") << endl;
}

int main() {
    // 1. Two empty strings, and an empty string against "0".
    show("1a.", Binary(""), Binary(""));
    show("1b.", Binary(""), Binary("0"));
    show("1c.", Binary("0"), Binary(""));

    // 2. A copy is equal; after one bit changes it is not.
    Binary a("10011");
    Binary b(a);
    show("2a.", a, b);
    b[4] = false;
    show("2b.", a, b);

    // 3. Long strings that differ only in the last bit or the first bit.
    show("3a.", Binary("1000000000000001"), Binary("1000000000000000"));
    show("3b.", Binary("0000000000000001"), Binary("1000000000000001"));

    // 4. A character other than '1' is a 0 bit.
    show("4.", Binary("1x"), Binary("10"));

    // 5. The same object.
    show("5.", a, a);

    // 6. The general template for double and char.
    cout << "6. " << isEqual(2.5, 2.5) << " " << isEqual('a', 'b') << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1a. [] and []: equal
1b. [] and [0]: not equal
1c. [0] and []: not equal
2a. [10011] and [10011]: equal
2b. [10011] and [10010]: not equal
3a. [1000000000000001] and [1000000000000000]: not equal
3b. [0000000000000001] and [1000000000000001]: not equal
4. [10] and [10]: equal
5. [10011] and [10011]: equal
6. 1 0
*/
