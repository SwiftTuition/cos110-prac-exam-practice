#include <iostream>

#include "Binary.h"
#include "BinaryStrings.h"
#include "Node.h"

using namespace std;

int main() {
    // 1. NULL.
    BinaryStrings list;
    cout << "1. NULL: " << list.countNegative(NULL) << endl;

    // 2. An empty string has no first bit, so it is not negative.
    list.prepend(Binary(""));
    cout << "2. [" << list << "]: " << list.countNegative(list.getHead()) << endl;

    // 3. Mixed list with empty strings at the front, middle and end.
    list.prepend(Binary("1"));
    list.prepend(Binary("0"));
    list.prepend(Binary(""));
    list.prepend(Binary("11111111"));
    list.prepend(Binary(""));
    cout << "3. [" << list << "]: " << list.countNegative(list.getHead()) << endl;

    // 4. All negative.
    BinaryStrings neg;
    for (int i = 0; i < 6; i++) {
        neg.prepend(Binary("10"));
    }
    cout << "4. " << neg << ": " << neg.countNegative(neg.getHead()) << endl;

    // 5. The list does not change.
    cout << "5. still " << neg << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. NULL: 0
2. []: 0
3. [ -> 11111111 ->  -> 0 -> 1 -> ]: 2
4. 10 -> 10 -> 10 -> 10 -> 10 -> 10: 6
5. still 10 -> 10 -> 10 -> 10 -> 10 -> 10
*/
