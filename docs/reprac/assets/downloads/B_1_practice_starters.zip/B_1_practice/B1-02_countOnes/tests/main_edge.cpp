#include <iostream>

#include "Binary.h"

using namespace std;

int main() {
    // 1. All ones and all zeros.
    Binary ones("11111");
    Binary zeros("00000");
    cout << "1. " << ones << ": " << ones.countOnes(0) << ", " << zeros << ": " << zeros.countOnes(0) << endl;

    // 2. The last bit only.
    Binary last("00001");
    cout << "2. " << last << " from index 4: " << last.countOnes(4) << endl;

    // 3. An empty string.
    Binary empty("");
    cout << "3. empty: " << empty.countOnes(0) << endl;

    // 4. Invalid indexes far outside the array.
    cout << "4. index -5: " << ones.countOnes(-5) << ", index 50: " << ones.countOnes(50) << endl;

    // 5. Every start index of 1101001, and the object does not change.
    Binary c("1101001");
    cout << "5.";
    for (int i = 0; i <= c.getSize(); i++) {
        cout << " " << c.countOnes(i);
    }
    cout << " (still " << c << ")" << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. 11111: 5, 00000: 0
2. 00001 from index 4: 1
3. empty: 0
4. index -5: 0, index 50: 0
5. 4 3 2 2 1 1 1 0 (still 1101001)
*/
