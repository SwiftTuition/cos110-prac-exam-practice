#include <iostream>

#include "Binary.h"

using namespace std;

int main() {
    // 1. One bit.
    Binary one("1");
    cout << "1. " << one << ": " << one.toDecimal(0) << endl;

    // 2. All zeros.
    Binary zeros("0000");
    cout << "2. " << zeros << ": " << zeros.toDecimal(3) << endl;

    // 3. Eight ones.
    Binary byte("11111111");
    cout << "3. " << byte << ": " << byte.toDecimal(7) << endl;

    // 4. A character that is not '1' is a 0 bit.
    Binary odd("1x1");
    cout << "4. " << odd << ": " << odd.toDecimal(2) << endl;

    // 5. 31 ones: the largest int.
    Binary big("1111111111111111111111111111111");
    cout << "5. 31 ones: " << big.toDecimal(30) << endl;

    // 6. An empty string: getSize() - 1 is -1.
    Binary empty("");
    cout << "6. empty: " << empty.toDecimal(empty.getSize() - 1) << endl;

    // 7. Index far past the end, and the size itself.
    cout << "7. index 100: " << byte.toDecimal(100) << ", index 8: " << byte.toDecimal(8) << endl;

    // 8. Every prefix of 110101, and the object does not change.
    Binary c("110101");
    cout << "8.";
    for (int i = 0; i < c.getSize(); i++) {
        cout << " " << c.toDecimal(i);
    }
    cout << " (still " << c << ")" << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. 1: 1
2. 0000: 0
3. 11111111: 255
4. 101: 5
5. 31 ones: 2147483647
6. empty: 0
7. index 100: 0, index 8: 0
8. 1 3 6 13 26 53 (still 110101)
*/
