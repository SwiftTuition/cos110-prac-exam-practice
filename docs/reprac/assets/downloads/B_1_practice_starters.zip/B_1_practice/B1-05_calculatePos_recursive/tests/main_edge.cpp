#include <iostream>

#include "Binary.h"
#include "BinaryStrings.h"
#include "Node.h"

using namespace std;

int main() {
    // 1. NULL.
    BinaryStrings list;
    cout << "1. NULL: " << list.calculatePos(NULL, 1) << endl;

    // 2. Strings that are not positive: empty, one bit, zero, negative.
    list.prepend(Binary("1000"));
    list.prepend(Binary("0000"));
    list.prepend(Binary("1"));
    list.prepend(Binary("0"));
    list.prepend(Binary(""));
    cout << "2. [" << list << "]: " << list.calculatePos(list.getHead(), 1) << endl;

    // 3. The 1 is far from the sign bit, and the next string is short.
    BinaryStrings mixed;
    mixed.prepend(Binary("01"));
    mixed.prepend(Binary("0000000001"));
    cout << "3. " << mixed << ": " << mixed.calculatePos(mixed.getHead(), 1) << endl;

    // 4. Positive strings between strings that are not positive.
    mixed.prepend(Binary("11"));
    mixed.prepend(Binary("010"));
    mixed.prepend(Binary(""));
    mixed.prepend(Binary("0111"));
    cout << "4. " << mixed << ": " << mixed.calculatePos(mixed.getHead(), 1) << endl;

    // 5. A start index past bit 1: only bits from index 3 of the first string are checked.
    BinaryStrings start;
    start.prepend(Binary("0001"));
    start.prepend(Binary("0100"));
    cout << "5. " << start << " from index 3: " << start.calculatePos(start.getHead(), 3) << endl;

    // 6. Negative index, and an index past the end of the first string.
    cout << "6. index -2: " << start.calculatePos(start.getHead(), -2)
         << ", index 9: " << start.calculatePos(start.getHead(), 9) << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. NULL: 0
2. [ -> 0 -> 1 -> 0000 -> 1000]: 0
3. 0000000001 -> 01: 2
4. 0111 ->  -> 010 -> 11 -> 0000000001 -> 01: 4
5. 0100 -> 0001 from index 3: 1
6. index -2: 0, index 9: 1
*/
