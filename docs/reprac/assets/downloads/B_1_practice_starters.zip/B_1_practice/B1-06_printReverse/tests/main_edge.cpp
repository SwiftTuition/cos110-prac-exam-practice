#include <iostream>
#include <string>

#include "Binary.h"
#include "BinaryStrings.h"
#include "Node.h"

using namespace std;

int main() {
    // 1. One node.
    BinaryStrings one;
    one.prepend(Binary("1"));
    cout << "1. one node:" << endl;
    one.printReverse(one.getHead());

    // 2. NULL prints nothing.
    cout << "2. NULL:" << endl;
    one.printReverse(NULL);
    cout << "(nothing above)" << endl;

    // 3. An empty string prints an empty line.
    BinaryStrings withEmpty;
    withEmpty.prepend(Binary("11"));
    withEmpty.prepend(Binary(""));
    withEmpty.prepend(Binary("00"));
    cout << "3. [" << withEmpty << "] in reverse:" << endl;
    withEmpty.printReverse(withEmpty.getHead());
    cout << "(end of 3)" << endl;

    // 4. Start at the last node.
    Node<Binary>* last = withEmpty.getHead()->next()->next();
    cout << "4. from the last node:" << endl;
    withEmpty.printReverse(last);

    // 5. Ten strings, and the list is not changed by printing.
    BinaryStrings many;
    string bits = "";
    for (int i = 0; i < 10; i++) {
        if (i % 2 == 0) {
            bits = bits + "1";
        } else {
            bits = bits + "0";
        }
        many.prepend(Binary(bits));
    }
    cout << "5. " << many << " in reverse:" << endl;
    many.printReverse(many.getHead());
    cout << "   after printing: " << many << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. one node:
1
2. NULL:
(nothing above)
3. [00 ->  -> 11] in reverse:
11

00
(end of 3)
4. from the last node:
11
5. 1010101010 -> 101010101 -> 10101010 -> 1010101 -> 101010 -> 10101 -> 1010 -> 101 -> 10 -> 1 in reverse:
1
10
101
1010
10101
101010
1010101
10101010
101010101
1010101010
   after printing: 1010101010 -> 101010101 -> 10101010 -> 1010101 -> 101010 -> 10101 -> 1010 -> 101 -> 10 -> 1
*/
