#include <iostream>

#include "Binary.h"

using namespace std;

int main() {
    // 1. An empty string.
    Binary empty("");
    cout << "1. empty: [" << empty << "] size " << empty.getSize() << endl;

    // 2. Characters that are not '1' become 0.
    Binary odd("1x0 1");
    cout << "2. \"1x0 1\": " << odd << endl;

    // 3. A shorter string changes only the first bits.
    Binary c("1111");
    c.setBits("0", 0);
    cout << "3. " << c << endl;

    // 4. A start index in the middle.
    Binary d("0000");
    d.setBits("1111", 2);
    cout << "4. " << d << endl;

    // 5. index equal to the size, and index equal to the string length: no change.
    d.setBits("1111", 4);
    d.setBits("00", 2);
    cout << "5. " << d << endl;

    // 6. Turn bits off.
    Binary e("11111111");
    e.setBits("10101010", 1);
    cout << "6. " << e << endl;

    // 7. A long string.
    Binary f("10000000000000000000000000000001");
    cout << "7. " << f << " (size " << f.getSize() << ")" << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. empty: [] size 0
2. "1x0 1": 10001
3. 0111
4. 0011
5. 0011
6. 10101010
7. 10000000000000000000000000000001 (size 32)
*/
