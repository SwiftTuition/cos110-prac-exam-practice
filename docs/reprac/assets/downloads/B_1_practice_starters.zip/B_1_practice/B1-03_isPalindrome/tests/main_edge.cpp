#include <iostream>

#include "Binary.h"

using namespace std;

void show(const char* label, Binary& b, int start, int end) {
    cout << label << " " << b << " [" << start << ", " << end << "]: " << (b.isPalindrome(start, end) ? "yes" : "no") << endl;
}

int main() {
    Binary one("1");
    Binary pair("10");
    Binary same("00");
    Binary empty("");
    Binary longer("110010111");
    Binary sym("1100110011");

    show("1. one bit:", one, 0, 0);
    show("2. two different bits:", pair, 0, 1);
    show("3. two equal bits:", same, 0, 1);
    show("4. empty string, whole range:", empty, 0, empty.getSize() - 1);
    show("5. start after end:", longer, 5, 2);
    show("6. outer bits equal, inner differ:", longer, 0, 8);
    show("7. long palindrome:", sym, 0, 9);
    show("8. part in the middle:", longer, 3, 6);
    show("9. end far past the array:", sym, 0, 40);
    show("10. both indexes negative:", sym, -3, -1);
    cout << "11. unchanged: " << sym << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. one bit: 1 [0, 0]: yes
2. two different bits: 10 [0, 1]: no
3. two equal bits: 00 [0, 1]: yes
4. empty string, whole range:  [0, -1]: yes
5. start after end: 110010111 [5, 2]: yes
6. outer bits equal, inner differ: 110010111 [0, 8]: no
7. long palindrome: 1100110011 [0, 9]: yes
8. part in the middle: 110010111 [3, 6]: no
9. end far past the array: 1100110011 [0, 40]: no
10. both indexes negative: 1100110011 [-3, -1]: no
11. unchanged: 1100110011
*/
