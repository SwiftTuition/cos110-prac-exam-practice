
#include <iostream>

#include "Exception.h"
#include "Item.h"
#include "Menu.h"

using namespace std;

void showFirst(Menu& menu, string type) {
    try {
        Item item = menu.findFirst(type);
        cout << "First " << type << ": " << item << endl;
    } catch (InvalidType& e) {
        cout << "InvalidType caught: ";
        e.printException();
    } catch (StarterNotFound& e) {
        cout << "StarterNotFound caught: ";
        e.printException();
    } catch (MainNotFound& e) {
        cout << "MainNotFound caught: ";
        e.printException();
    } catch (DessertNotFound& e) {
        cout << "DessertNotFound caught: ";
        e.printException();
    } catch (Exception& e) {
        cout << "Exception caught: ";
        e.printException();
    }
}

int main() {
    cout << "-- a full menu --" << endl;
    Menu full(3);
    full + new Item('S', "Soup", 50) + new Item('S', "Samoosas", 40) + new Item('M', "Lamb chops", 185.5);
    showFirst(full, "Starter");
    showFirst(full, "Main");
    showFirst(full, "Dessert");
    showFirst(full, "main");

    cout << "-- a menu of size 0 --" << endl;
    Menu none(0);
    showFirst(none, "Main");
    showFirst(none, "Pizza");

    cout << "-- an empty menu: the type is checked first --" << endl;
    Menu empty(2);
    showFirst(empty, "Drink");
    showFirst(empty, "Starter");

    cout << "-- the menu is unchanged --" << endl;
    cout << full;
    return 0;
}
/*
ExpectedOutput:
*/
/*
-- a full menu --
First Starter: Soup (S) R50
First Main: Lamb chops (M) R185.5
DessertNotFound caught: Exception: Item not found
InvalidType caught: Exception: Invalid type: main
-- a menu of size 0 --
MainNotFound caught: Exception: Item not found
InvalidType caught: Exception: Invalid type: Pizza
-- an empty menu: the type is checked first --
InvalidType caught: Exception: Invalid type: Drink
StarterNotFound caught: Exception: Item not found
-- the menu is unchanged --
Menu (max 3):
  [0] Soup (S) R50
  [1] Samoosas (S) R40
  [2] Lamb chops (M) R185.5
*/
