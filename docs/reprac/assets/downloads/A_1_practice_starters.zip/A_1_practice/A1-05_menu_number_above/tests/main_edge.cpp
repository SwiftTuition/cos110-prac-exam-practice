
#include <iostream>

#include "Exception.h"
#include "Item.h"
#include "Menu.h"

using namespace std;

void show(Menu& menu, string type, float value) {
    try {
        int count = menu.numberAbove(type, value);
        cout << type << " above R" << value << ": " << count << endl;
    } catch (InvalidType& e) {
        cout << "InvalidType caught: ";
        e.printException();
    } catch (NothingAboveMinimumValue& e) {
        cout << "NothingAboveMinimumValue caught: ";
        e.printException();
    } catch (NothingBelowMaximumValue& e) {
        cout << "NothingBelowMaximumValue caught: ";
        e.printException();
    } catch (NothingMatchingFilter& e) {
        cout << "NothingMatchingFilter caught: ";
        e.printException();
    } catch (Exception& e) {
        cout << "Exception caught: ";
        e.printException();
    }
}

int main() {
    cout << "-- a full menu --" << endl;
    Menu full(3);
    full + new Item('M', "Lamb chops", 185.5) + new Item('M', "Fish and chips", 110);
    full + new Item('S', "Free bread", 0);
    show(full, "Main", 110);
    show(full, "Main", 0);
    show(full, "Starter", -1);
    show(full, "Starter", 0);
    show(full, "Dessert", 0);

    cout << "-- a menu of size 0 --" << endl;
    Menu none(0);
    show(none, "Main", 0);
    show(none, "Mains", 0);

    cout << "-- an empty menu: the type is checked first --" << endl;
    Menu empty(2);
    show(empty, "Drink", 0);
    return 0;
}
/*
ExpectedOutput:
*/
/*
-- a full menu --
Main above R110: 1
Main above R0: 2
Starter above R-1: 1
NothingAboveMinimumValue caught: Exception: Nothing matching filter: above minimum value
NothingAboveMinimumValue caught: Exception: Nothing matching filter: above minimum value
-- a menu of size 0 --
NothingAboveMinimumValue caught: Exception: Nothing matching filter: above minimum value
InvalidType caught: Exception: Invalid type: Mains
-- an empty menu: the type is checked first --
InvalidType caught: Exception: Invalid type: Drink
*/
