
#include <iostream>

#include "Exception.h"
#include "Item.h"
#include "Menu.h"

using namespace std;

void showLast(Menu& menu, string type) {
    try {
        Item item = menu.findLast(type);
        cout << "Last " << type << ": " << item << endl;
    } catch (InvalidType& e) {
        cout << "InvalidType caught: ";
        e.printException();
    } catch (StarterNotFound& e) {
        cout << "StarterNotFound caught: ";
        e.printException();
    } catch (MainNotFound& e) {
        cout << "MainNotFound caught: ";
        e.printException();
    } catch (DessertNotFound& e) {
        cout << "DessertNotFound caught: ";
        e.printException();
    } catch (Exception& e) {
        cout << "Exception caught: ";
        e.printException();
    }
}

int main() {
    cout << "-- a full menu --" << endl;
    Menu full(3);
    full + new Item('D', "Peppermint tart", 55) + new Item('M', "Lamb chops", 185.5);
    full + new Item('M', "Fish and chips", 110);
    showLast(full, "Dessert");
    showLast(full, "Main");
    showLast(full, "Starter");

    cout << "-- a menu of size 0 --" << endl;
    Menu none(0);
    showLast(none, "Dessert");
    showLast(none, "Snack");

    cout << "-- an empty menu: the type is checked first --" << endl;
    Menu empty(2);
    showLast(empty, "Drink");

    cout << "-- the menu is unchanged --" << endl;
    cout << full;
    return 0;
}
/*
ExpectedOutput:
*/
/*
-- a full menu --
Last Dessert: Peppermint tart (D) R55
Last Main: Fish and chips (M) R110
StarterNotFound caught: Exception: Item not found
-- a menu of size 0 --
DessertNotFound caught: Exception: Item not found
InvalidType caught: Exception: Invalid type: Snack
-- an empty menu: the type is checked first --
InvalidType caught: Exception: Invalid type: Drink
-- the menu is unchanged --
Menu (max 3):
  [0] Peppermint tart (D) R55
  [1] Lamb chops (M) R185.5
  [2] Fish and chips (M) R110
*/
