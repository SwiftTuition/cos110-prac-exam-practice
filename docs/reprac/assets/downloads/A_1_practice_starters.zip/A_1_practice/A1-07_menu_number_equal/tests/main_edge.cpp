
#include <iostream>

#include "Exception.h"
#include "Item.h"
#include "Menu.h"

using namespace std;

void show(Menu& menu, string type, float value) {
    try {
        int count = menu.numberEqual(type, value);
        cout << type << " equal to R" << value << ": " << count << endl;
    } catch (InvalidType& e) {
        cout << "InvalidType caught: ";
        e.printException();
    } catch (NothingAboveMinimumValue& e) {
        cout << "NothingAboveMinimumValue caught: ";
        e.printException();
    } catch (NothingBelowMaximumValue& e) {
        cout << "NothingBelowMaximumValue caught: ";
        e.printException();
    } catch (NothingMatchingFilter& e) {
        cout << "NothingMatchingFilter caught: ";
        e.printException();
    } catch (Exception& e) {
        cout << "Exception caught: ";
        e.printException();
    }
}

int main() {
    cout << "-- a full menu --" << endl;
    Menu full(3);
    full + new Item('D', "Ice cream", 35) + new Item('D', "Sorbet", 35);
    full + new Item('D', "Free mints", 0);
    show(full, "Dessert", 35);
    show(full, "Dessert", 0);
    show(full, "Dessert", 35.25);
    show(full, "Main", 35);

    cout << "-- a menu of size 0 --" << endl;
    Menu none(0);
    show(none, "Starter", 0);
    show(none, "Mains", 0);

    cout << "-- an empty menu: the type is checked first --" << endl;
    Menu empty(2);
    show(empty, "Drink", 0);
    return 0;
}
/*
ExpectedOutput:
*/
/*
-- a full menu --
Dessert equal to R35: 2
Dessert equal to R0: 1
NothingMatchingFilter caught: Exception: Nothing matching filter: Dessert
NothingMatchingFilter caught: Exception: Nothing matching filter: Main
-- a menu of size 0 --
NothingMatchingFilter caught: Exception: Nothing matching filter: Starter
InvalidType caught: Exception: Invalid type: Mains
-- an empty menu: the type is checked first --
InvalidType caught: Exception: Invalid type: Drink
*/
