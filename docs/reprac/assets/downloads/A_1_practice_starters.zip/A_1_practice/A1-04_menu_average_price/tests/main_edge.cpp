
#include <iostream>

#include "Exception.h"
#include "Item.h"
#include "Menu.h"

using namespace std;

void showAverage(Menu& menu, string type) {
    try {
        float average = menu.averagePrice(type);
        cout << "Average " << type << " price: R" << average << endl;
    } catch (InvalidType& e) {
        cout << "InvalidType caught: ";
        e.printException();
    } catch (NothingMatchingFilter& e) {
        cout << "NothingMatchingFilter caught: ";
        e.printException();
    } catch (Exception& e) {
        cout << "Exception caught: ";
        e.printException();
    }
}

int main() {
    cout << "-- three desserts in a full menu --" << endl;
    Menu full(3);
    full + new Item('D', "Ice cream", 10.5) + new Item('D', "Malva pudding", 20.25);
    full + new Item('D', "Cheesecake", 30.75);
    showAverage(full, "Dessert");
    showAverage(full, "Main");

    cout << "-- a free item still counts --" << endl;
    Menu freebies(2);
    freebies + new Item('S', "Free bread", 0);
    showAverage(freebies, "Starter");

    cout << "-- a menu of size 0 --" << endl;
    Menu none(0);
    showAverage(none, "Starter");
    showAverage(none, "Pudding");

    cout << "-- an empty menu: the type is checked first --" << endl;
    Menu empty(2);
    showAverage(empty, "Drink");
    showAverage(empty, "Dessert");
    return 0;
}
/*
ExpectedOutput:
*/
/*
-- three desserts in a full menu --
Average Dessert price: R20.5
NothingMatchingFilter caught: Exception: Nothing matching filter: Main
-- a free item still counts --
Average Starter price: R0
-- a menu of size 0 --
NothingMatchingFilter caught: Exception: Nothing matching filter: Starter
InvalidType caught: Exception: Invalid type: Pudding
-- an empty menu: the type is checked first --
InvalidType caught: Exception: Invalid type: Drink
NothingMatchingFilter caught: Exception: Nothing matching filter: Dessert
*/
