
#include <iostream>

#include "Exception.h"
#include "Item.h"
#include "Menu.h"

using namespace std;

void show(Menu& menu, string type, float value) {
    try {
        int count = menu.numberBelow(type, value);
        cout << type << " below R" << value << ": " << count << endl;
    } catch (InvalidType& e) {
        cout << "InvalidType caught: ";
        e.printException();
    } catch (NothingAboveMinimumValue& e) {
        cout << "NothingAboveMinimumValue caught: ";
        e.printException();
    } catch (NothingBelowMaximumValue& e) {
        cout << "NothingBelowMaximumValue caught: ";
        e.printException();
    } catch (NothingMatchingFilter& e) {
        cout << "NothingMatchingFilter caught: ";
        e.printException();
    } catch (Exception& e) {
        cout << "Exception caught: ";
        e.printException();
    }
}

int main() {
    cout << "-- a full menu --" << endl;
    Menu full(3);
    full + new Item('D', "Ice cream", 35) + new Item('D', "Cheesecake", 65.5);
    full + new Item('S', "Free bread", 0);
    show(full, "Dessert", 65.5);
    show(full, "Dessert", 1000);
    show(full, "Dessert", 35);
    show(full, "Starter", 0.5);
    show(full, "Starter", 0);
    show(full, "Main", 1000);

    cout << "-- a menu of size 0 --" << endl;
    Menu none(0);
    show(none, "Dessert", 1000);
    show(none, "Sides", 1000);

    cout << "-- an empty menu: the type is checked first --" << endl;
    Menu empty(2);
    show(empty, "Drink", 1000);
    return 0;
}
/*
ExpectedOutput:
*/
/*
-- a full menu --
Dessert below R65.5: 1
Dessert below R1000: 2
NothingBelowMaximumValue caught: Exception: Nothing matching filter: below maximum value
Starter below R0.5: 1
NothingBelowMaximumValue caught: Exception: Nothing matching filter: below maximum value
NothingBelowMaximumValue caught: Exception: Nothing matching filter: below maximum value
-- a menu of size 0 --
NothingBelowMaximumValue caught: Exception: Nothing matching filter: below maximum value
InvalidType caught: Exception: Invalid type: Sides
-- an empty menu: the type is checked first --
InvalidType caught: Exception: Invalid type: Drink
*/
