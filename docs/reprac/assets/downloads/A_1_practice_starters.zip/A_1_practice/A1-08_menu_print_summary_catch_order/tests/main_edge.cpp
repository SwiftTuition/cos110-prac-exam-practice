
#include <iostream>

#include "Exception.h"
#include "Item.h"
#include "Menu.h"

using namespace std;

void check(Menu& menu, string type, float minPrice) {
    bool ok = menu.printSummary(type, minPrice);
    cout << "  returned " << (ok ? "true" : "false") << endl;
}

int main() {
    cout << "-- a full menu of desserts --" << endl;
    Menu full(2);
    full + new Item('D', "Cheesecake", 65.5) + new Item('D', "Ice cream", 35);
    check(full, "Dessert", 0);
    check(full, "Dessert", 65.5);
    check(full, "dessert", 0);
    check(full, "Starter", 1000);

    cout << "-- a menu of size 0 --" << endl;
    Menu none(0);
    check(none, "Dessert", 0);
    check(none, "Main", -5);
    check(none, "Sides", 0);

    cout << "-- the menu is unchanged --" << endl;
    cout << full;
    return 0;
}
/*
ExpectedOutput:
*/
/*
-- a full menu of desserts --
Dessert: first is Cheesecake (D) R65.5, 2 above R0
  returned true
Nothing above R65.5. Exception: Nothing matching filter: above minimum value
  returned false
Request failed. Exception: Invalid type: dessert
  returned false
Not on the menu. Exception: Item not found
  returned false
-- a menu of size 0 --
No desserts yet. Exception: Item not found
  returned false
Not on the menu. Exception: Item not found
  returned false
Request failed. Exception: Invalid type: Sides
  returned false
-- the menu is unchanged --
Menu (max 2):
  [0] Cheesecake (D) R65.5
  [1] Ice cream (D) R35
*/
