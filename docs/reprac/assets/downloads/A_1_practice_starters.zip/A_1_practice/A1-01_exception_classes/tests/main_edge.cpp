
#include <iostream>

#include "Exception.h"

using namespace std;

void show(Exception& e) {
    cout << "[" << e << "] ";
    e.printException();
}

int main() {
    cout << "-- each class through a base reference --" << endl;
    InvalidType a("starter");
    NothingMatchingFilter b("Main");
    NothingAboveMinimumValue c;
    NothingBelowMaximumValue d;
    NotFoundException e;
    StarterNotFound f;
    MainNotFound g;
    DessertNotFound h;
    show(a);
    show(b);
    show(c);
    show(d);
    show(e);
    show(f);
    show(g);
    show(h);

    cout << "-- through a base pointer --" << endl;
    Exception* p = new MainNotFound();
    p->printException();
    delete p;
    p = new NothingBelowMaximumValue();
    p->printException();
    delete p;

    cout << "-- a copy keeps the message --" << endl;
    InvalidType copy(a);
    copy.printException();

    cout << "-- caught by the middle class --" << endl;
    try {
        throw NothingAboveMinimumValue();
    } catch (NothingMatchingFilter& ex) {
        ex.printException();
    }
    try {
        throw DessertNotFound();
    } catch (NotFoundException& ex) {
        ex.printException();
    }
    return 0;
}
/*
ExpectedOutput:
*/
/*
-- each class through a base reference --
[Exception: Invalid type: starter] Exception: Invalid type: starter
[Exception: Nothing matching filter: Main] Exception: Nothing matching filter: Main
[Exception: Nothing matching filter: above minimum value] Exception: Nothing matching filter: above minimum value
[Exception: Nothing matching filter: below maximum value] Exception: Nothing matching filter: below maximum value
[Exception: Item not found] Exception: Item not found
[Exception: Item not found] Exception: Item not found
[Exception: Item not found] Exception: Item not found
[Exception: Item not found] Exception: Item not found
-- through a base pointer --
Exception: Item not found
Exception: Nothing matching filter: below maximum value
-- a copy keeps the message --
Exception: Invalid type: starter
-- caught by the middle class --
Exception: Nothing matching filter: above minimum value
Exception: Item not found
*/
