#include <iostream>

#include "Binary.h"
#include "BinaryStrings.h"
#include "Node.h"

using namespace std;

void tryRemove(const char* label, BinaryStrings& list, int pos) {
    bool removed = list.removeAt(pos);
    cout << label << " removeAt(" << pos << "): " << (removed ? "true" : "false") << ", [" << list
         << "] size " << list.getSize() << endl;
}

int main() {
    // 1. Empty list.
    BinaryStrings list;
    tryRemove("1.", list, 0);

    // 2. One node: position 1 is invalid, position 0 empties the list.
    list.prepend(Binary("11111111"));
    tryRemove("2a.", list, 1);
    tryRemove("2b.", list, 0);
    cout << "    head is NULL: " << (list.getHead() == NULL ? "yes" : "no") << endl;

    // 3. Remove the last node: the new last node's next() is NULL.
    BinaryStrings three;
    three.prepend(Binary("0"));
    three.prepend(Binary(""));
    three.prepend(Binary("10"));
    tryRemove("3.", three, 2);
    Node<Binary>* last = three.getHead()->next();
    cout << "    last is [" << last->getData() << "], next is NULL: " << (last->next() == NULL ? "yes" : "no") << endl;

    // 4. A position equal to the size, and a large negative position.
    tryRemove("4a.", three, 2);
    tryRemove("4b.", three, -100);

    // 5. Remove from the middle of a long list until it is empty.
    BinaryStrings many;
    for (int i = 0; i < 6; i++) {
        if (i % 2 == 0) {
            many.prepend(Binary("01"));
        } else {
            many.prepend(Binary("10"));
        }
    }
    cout << "5. " << many << endl;
    while (many.getSize() > 0) {
        many.removeAt(many.getSize() / 2);
    }
    cout << "   after removing the middle each time: " << many << " (size " << many.getSize() << ")" << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. removeAt(0): false, [Empty] size 0
2a. removeAt(1): false, [11111111] size 1
2b. removeAt(0): true, [Empty] size 0
    head is NULL: yes
3. removeAt(2): true, [10 -> ] size 2
    last is [], next is NULL: yes
4a. removeAt(2): false, [10 -> ] size 2
4b. removeAt(-100): false, [10 -> ] size 2
5. 10 -> 01 -> 10 -> 01 -> 10 -> 01
   after removing the middle each time: Empty (size 0)
*/
