#include <iostream>

#include "Binary.h"
#include "BinaryStrings.h"
#include "Node.h"

using namespace std;

void tryRemove(const char* label, BinaryStrings& list, string bits) {
    bool removed = list.remove(Binary(bits));
    cout << label << " remove(\"" << bits << "\"): " << (removed ? "true" : "false") << ", [" << list
         << "] size " << list.getSize() << endl;
}

int main() {
    // 1. Empty list.
    BinaryStrings list;
    tryRemove("1a.", list, "1");

    // 1b. The stored string is shorter than b: not equal. Then remove it.
    list.prepend(Binary("1"));
    tryRemove("1b.", list, "11");
    tryRemove("1c.", list, "1");

    // 2. Strings with the same value but a different length are not equal.
    list.prepend(Binary("11"));
    list.prepend(Binary("011"));
    list.prepend(Binary("0011"));
    tryRemove("2a.", list, "00011");
    tryRemove("2b.", list, "1");
    tryRemove("2c.", list, "011");

    // 3. The last node: the new last node's next() is NULL.
    tryRemove("3.", list, "11");
    cout << "    last is " << list.getHead()->getData() << ", next is NULL: "
         << (list.getHead()->next() == NULL ? "yes" : "no") << endl;

    // 4. The only node.
    tryRemove("4.", list, "0011");

    // 5. Empty strings: only an empty string equals an empty string.
    BinaryStrings e;
    e.prepend(Binary("0"));
    e.prepend(Binary(""));
    e.prepend(Binary("0"));
    tryRemove("5a.", e, "");
    tryRemove("5b.", e, "");
    tryRemove("5c.", e, "00");

    // 6. A difference only in the last bit.
    BinaryStrings f;
    f.prepend(Binary("10000001"));
    f.prepend(Binary("10000000"));
    tryRemove("6.", f, "10000001");

    // 7. A character other than '1' is a 0 bit, so "1x" equals "10".
    BinaryStrings g;
    g.prepend(Binary("10"));
    tryRemove("7.", g, "1x");
    return 0;
}
/*
ExpectedOutput:
*/
/*
1a. remove("1"): false, [Empty] size 0
1b. remove("11"): false, [1] size 1
1c. remove("1"): true, [Empty] size 0
2a. remove("00011"): false, [0011 -> 011 -> 11] size 3
2b. remove("1"): false, [0011 -> 011 -> 11] size 3
2c. remove("011"): true, [0011 -> 11] size 2
3. remove("11"): true, [0011] size 1
    last is 0011, next is NULL: yes
4. remove("0011"): true, [Empty] size 0
5a. remove(""): true, [0 -> 0] size 2
5b. remove(""): false, [0 -> 0] size 2
5c. remove("00"): false, [0 -> 0] size 2
6. remove("10000001"): true, [10000000] size 1
7. remove("1x"): true, [Empty] size 0
*/
