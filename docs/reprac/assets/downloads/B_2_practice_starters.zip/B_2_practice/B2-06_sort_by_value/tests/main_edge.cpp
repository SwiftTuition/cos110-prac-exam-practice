#include <iostream>

#include "Binary.h"
#include "BinaryStrings.h"
#include "Node.h"

using namespace std;

// Checks that the list after sort() uses the same nodes as before (no new nodes).
bool sameNodes(Node<Binary>** before, int count, BinaryStrings& list) {
    int found = 0;
    Node<Binary>* curr = list.getHead();
    while (curr != NULL) {
        bool known = false;
        for (int i = 0; i < count; i++) {
            if (before[i] == curr) {
                known = true;
            }
        }
        if (!known) {
            return false;
        }
        found++;
        curr = curr->next();
    }
    return found == count;
}

int main() {
    // 1. One node.
    BinaryStrings one;
    one.prepend(Binary("101"));
    one.sort();
    cout << "1. " << one << " (size " << one.getSize() << ")" << endl;

    // 2. Already sorted, and sorted in reverse.
    BinaryStrings up;
    up.prepend(Binary("11"));
    up.prepend(Binary("10"));
    up.prepend(Binary("1"));
    up.sort();
    cout << "2a. " << up << endl;
    BinaryStrings down;
    down.prepend(Binary("1"));
    down.prepend(Binary("10"));
    down.prepend(Binary("11"));
    down.sort();
    cout << "2b. " << down << endl;

    // 3. Equal values with different lengths keep their order.
    BinaryStrings ties;
    ties.prepend(Binary("0001"));
    ties.prepend(Binary("10"));
    ties.prepend(Binary("1"));
    ties.prepend(Binary("010"));
    ties.prepend(Binary("01"));
    ties.prepend(Binary(""));
    ties.prepend(Binary("0"));
    cout << "3. [" << ties << "]" << endl;
    ties.sort();
    cout << "   [" << ties << "]" << endl;

    // 4. The same nodes are reused, and the last node's next() is NULL.
    BinaryStrings list;
    list.prepend(Binary("0110"));
    list.prepend(Binary("11111"));
    list.prepend(Binary("0"));
    list.prepend(Binary("1001"));
    list.prepend(Binary("0011"));
    list.prepend(Binary("10"));
    Node<Binary>* before[6];
    Node<Binary>* curr = list.getHead();
    for (int i = 0; i < 6; i++) {
        before[i] = curr;
        curr = curr->next();
    }
    cout << "4. " << list << endl;
    list.sort();
    cout << "   " << list << " (size " << list.getSize() << ")" << endl;
    cout << "   Same nodes: " << (sameNodes(before, 6, list) ? "yes" : "no") << endl;
    curr = list.getHead();
    while (curr->next() != NULL) {
        curr = curr->next();
    }
    cout << "   last is " << curr->getData() << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. 101 (size 1)
2a. 1 -> 10 -> 11
2b. 1 -> 10 -> 11
3. [0 ->  -> 01 -> 010 -> 1 -> 10 -> 0001]
   [0 ->  -> 01 -> 1 -> 0001 -> 010 -> 10]
4. 10 -> 0011 -> 1001 -> 0 -> 11111 -> 0110
   0 -> 10 -> 0011 -> 0110 -> 1001 -> 11111 (size 6)
   Same nodes: yes
   last is 11111
*/
