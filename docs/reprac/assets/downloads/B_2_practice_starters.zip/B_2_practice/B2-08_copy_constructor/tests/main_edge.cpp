#include <iostream>

#include "Binary.h"
#include "BinaryStrings.h"
#include "Node.h"

using namespace std;

// Pass by value: the copy constructor makes the parameter.
int countNodes(BinaryStrings list) {
    int count = 0;
    Node<Binary>* curr = list.getHead();
    while (curr != NULL) {
        count++;
        curr = curr->next();
    }
    return count;
}

int main() {
    // 1. One node: a different node with an equal string.
    BinaryStrings one;
    one.prepend(Binary("1"));
    BinaryStrings oneCopy(one);
    cout << "1. " << oneCopy << " (size " << oneCopy.getSize() << "), different node: "
         << (oneCopy.getHead() != one.getHead() ? "yes" : "no") << endl;

    // 2. No node is shared, and the last node's next() is NULL.
    BinaryStrings list;
    list.prepend(Binary("11"));
    list.prepend(Binary(""));
    list.prepend(Binary("0"));
    list.prepend(Binary("1010"));
    BinaryStrings copy(list);
    bool shared = false;
    Node<Binary>* a = list.getHead();
    Node<Binary>* b = copy.getHead();
    Node<Binary>* lastCopy = NULL;
    while (a != NULL && b != NULL) {
        if (a == b) {
            shared = true;
        }
        lastCopy = b;
        a = a->next();
        b = b->next();
    }
    cout << "2. [" << copy << "] size " << copy.getSize() << ", shared nodes: " << (shared ? "yes" : "no")
         << ", last is [" << lastCopy->getData() << "]" << endl;

    // 3. A copy of a copy, then change the middle copy.
    BinaryStrings copy2(copy);
    copy.getHead()->next()->getData()[0] = true;
    cout << "3. list [" << list << "]" << endl;
    cout << "   copy [" << copy << "]" << endl;
    cout << "   copy2 [" << copy2 << "]" << endl;

    // 4. Pass by value uses the copy constructor.
    cout << "4. countNodes(list): " << countNodes(list) << ", list still [" << list << "]" << endl;

    // 5. Ten nodes in order.
    BinaryStrings many;
    for (int i = 0; i < 10; i++) {
        if (i % 3 == 0) {
            many.prepend(Binary("0"));
        } else {
            many.prepend(Binary("1"));
        }
    }
    BinaryStrings manyCopy(many);
    cout << "5. " << manyCopy << " (size " << manyCopy.getSize() << ")" << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. 1 (size 1), different node: yes
2. [1010 -> 0 ->  -> 11] size 4, shared nodes: no, last is [11]
3. list [1010 -> 0 ->  -> 11]
   copy [1010 -> 1 ->  -> 11]
   copy2 [1010 -> 0 ->  -> 11]
4. countNodes(list): 4, list still [1010 -> 0 ->  -> 11]
5. 0 -> 1 -> 1 -> 0 -> 1 -> 1 -> 0 -> 1 -> 1 -> 0 (size 10)
*/
