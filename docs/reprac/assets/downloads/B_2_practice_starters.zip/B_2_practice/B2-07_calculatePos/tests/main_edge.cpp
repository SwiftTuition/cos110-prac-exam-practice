#include <iostream>

#include "Binary.h"
#include "BinaryStrings.h"
#include "Node.h"

using namespace std;

int main() {
    // 1. Strings that are not positive: empty, one bit, zero, negative.
    BinaryStrings list;
    list.prepend(Binary("1000"));
    list.prepend(Binary("0000"));
    list.prepend(Binary("1"));
    list.prepend(Binary("0"));
    list.prepend(Binary(""));
    cout << "1. [" << list << "]: " << list.calculatePos() << endl;

    // 2. Positive strings with one 1 and with many 1s are each counted once.
    BinaryStrings pos;
    pos.prepend(Binary("01"));
    pos.prepend(Binary("0111111"));
    pos.prepend(Binary("0000000001"));
    cout << "2. " << pos << ": " << pos.calculatePos() << endl;

    // 3. Mixed, with empty strings between the others.
    BinaryStrings mixed;
    mixed.prepend(Binary("01"));
    mixed.prepend(Binary(""));
    mixed.prepend(Binary("11"));
    mixed.prepend(Binary("010"));
    mixed.prepend(Binary(""));
    mixed.prepend(Binary("1111"));
    cout << "3. [" << mixed << "]: " << mixed.calculatePos() << endl;

    // 4. A character other than '1' is a 0 bit.
    BinaryStrings odd;
    odd.prepend(Binary("0x"));
    odd.prepend(Binary("x1"));
    cout << "4. " << odd << ": " << odd.calculatePos() << endl;

    // 5. The list does not change.
    cout << "5. [" << mixed << "] size " << mixed.getSize() << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. [ -> 0 -> 1 -> 0000 -> 1000]: 0
2. 0000000001 -> 0111111 -> 01: 3
3. [1111 ->  -> 010 -> 11 ->  -> 01]: 2
4. 01 -> 00: 1
5. [1111 ->  -> 010 -> 11 ->  -> 01] size 6
*/
