#include <iostream>

#include "Binary.h"
#include "BinaryStrings.h"
#include "Node.h"

using namespace std;

int main() {
    // 1. Append to an empty list, then the head is the new node.
    BinaryStrings list;
    list.append(Binary("1"));
    cout << "1. " << list << ", head " << list.getHead()->getData() << ", size " << list.getSize() << endl;

    // 2. The last node's next() is NULL.
    list.append(Binary("10"));
    Node<Binary>* last = list.getHead()->next();
    cout << "2. last " << last->getData() << ", next is NULL: " << (last->next() == NULL ? "yes" : "no") << endl;

    // 3. An empty string can be appended.
    list.append(Binary(""));
    cout << "3. [" << list << "] size " << list.getSize() << endl;

    // 4. Many appends keep the order.
    BinaryStrings many;
    for (int i = 0; i < 8; i++) {
        if (i % 2 == 0) {
            many.append(Binary("0"));
        } else {
            many.append(Binary("1"));
        }
    }
    cout << "4. " << many << " (size " << many.getSize() << ")" << endl;

    // 5. Change a string inside the list: only that node changes.
    many.getHead()->getData()[0] = true;
    cout << "5. " << many << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. 1, head 1, size 1
2. last 10, next is NULL: yes
3. [1 -> 10 -> ] size 3
4. 0 -> 1 -> 0 -> 1 -> 0 -> 1 -> 0 -> 1 (size 8)
5. 1 -> 1 -> 0 -> 1 -> 0 -> 1 -> 0 -> 1
*/
