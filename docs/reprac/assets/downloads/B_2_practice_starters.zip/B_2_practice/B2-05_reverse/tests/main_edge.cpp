#include <iostream>

#include "Binary.h"
#include "BinaryStrings.h"
#include "Node.h"

using namespace std;

int main() {
    // 1. One node.
    BinaryStrings one;
    one.prepend(Binary("1"));
    one.reverse();
    cout << "1. " << one << ", next is NULL: " << (one.getHead()->next() == NULL ? "yes" : "no") << endl;

    // 2. Two nodes.
    BinaryStrings two;
    two.prepend(Binary("10"));
    two.prepend(Binary("01"));
    two.reverse();
    cout << "2. " << two << endl;

    // 3. The same nodes are used: the old last node is the new head.
    BinaryStrings list;
    list.prepend(Binary("11"));
    list.prepend(Binary(""));
    list.prepend(Binary("0"));
    list.prepend(Binary("1010"));
    Node<Binary>* oldHead = list.getHead();
    Node<Binary>* oldLast = list.getHead()->next()->next()->next();
    list.reverse();
    cout << "3. [" << list << "] size " << list.getSize() << endl;
    cout << "   new head is the old last node: " << (list.getHead() == oldLast ? "yes" : "no") << endl;
    cout << "   old head is last, next is NULL: " << (oldHead->next() == NULL ? "yes" : "no") << endl;

    // 4. Changing the new head changes the node that was last.
    list.getHead()->getData()[0] = false;
    cout << "4. [" << list << "]" << endl;

    // 5. Ten strings.
    BinaryStrings many;
    for (int i = 0; i < 10; i++) {
        if (i < 5) {
            many.prepend(Binary("0"));
        } else {
            many.prepend(Binary("1"));
        }
    }
    cout << "5. " << many << endl;
    many.reverse();
    cout << "   " << many << " (size " << many.getSize() << ")" << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. 1, next is NULL: yes
2. 10 -> 01
3. [11 ->  -> 0 -> 1010] size 4
   new head is the old last node: yes
   old head is last, next is NULL: yes
4. [01 ->  -> 0 -> 1010]
5. 1 -> 1 -> 1 -> 1 -> 1 -> 0 -> 0 -> 0 -> 0 -> 0
   0 -> 0 -> 0 -> 0 -> 0 -> 1 -> 1 -> 1 -> 1 -> 1 (size 10)
*/
