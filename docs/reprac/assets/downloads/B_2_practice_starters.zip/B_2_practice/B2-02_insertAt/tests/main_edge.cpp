#include <iostream>

#include "Binary.h"
#include "BinaryStrings.h"
#include "Node.h"

using namespace std;

void show(const char* label, BinaryStrings& list) {
    cout << label << " " << list << " (size " << list.getSize() << ")" << endl;
}

int main() {
    // 1. Empty list with a large position: the new node is the only node.
    BinaryStrings list;
    list.insertAt(Binary("1"), 5);
    show("1.", list);

    // 2. Position equal to the size: append.
    list.insertAt(Binary("10"), 1);
    show("2.", list);

    // 3. Position size - 1: before the last node.
    list.insertAt(Binary("11"), 1);
    show("3.", list);

    // 4. Position 1 in a longer list.
    list.insertAt(Binary("0"), 1);
    show("4.", list);

    // 5. Insert at every position of a new list: positions 0, 1, 2, 3, 4.
    BinaryStrings order;
    order.insertAt(Binary("100"), 0);
    order.insertAt(Binary("011"), 0);
    order.insertAt(Binary("010"), 1);
    order.insertAt(Binary("001"), 0);
    order.insertAt(Binary("101"), 4);
    show("5.", order);

    // 6. The last node's next() is NULL after an append.
    Node<Binary>* curr = order.getHead();
    while (curr->next() != NULL) {
        curr = curr->next();
    }
    cout << "6. last is " << curr->getData() << endl;
    return 0;
}
/*
ExpectedOutput:
*/
/*
1. 1 (size 1)
2. 1 -> 10 (size 2)
3. 1 -> 11 -> 10 (size 3)
4. 1 -> 0 -> 11 -> 10 (size 4)
5. 001 -> 011 -> 010 -> 100 -> 101 (size 5)
6. last is 101
*/
